CREATE VIEW dbo.lisquyu
AS
SELECT     dbo.lis_buy.dengdancode, dbo.lis_buysave.dengdancode AS ddcode
FROM         dbo.lis_buysave INNER JOIN
                      dbo.lis_buy ON dbo.lis_buysave.dengdancode = dbo.lis_buy.dengdancode
go

