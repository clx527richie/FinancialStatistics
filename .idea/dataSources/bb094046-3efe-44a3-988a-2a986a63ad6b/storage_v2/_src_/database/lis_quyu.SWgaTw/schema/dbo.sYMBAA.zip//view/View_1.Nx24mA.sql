CREATE VIEW dbo.View_1
AS
SELECT     dbo.lis_buy_bak.buy_id, dbo.lis_buy_bak.buy_name, dbo.lis_buy_bak.buy_price, dbo.lis_buy_bak.buy_priceyj, dbo.lis_buy_bak.buy_tips, dbo.lis_buy_bak.buy_time, 
                      dbo.lis_buy_bak.hospitalcode, dbo.lis_buy_bak.pat_name, dbo.lis_buy_bak.sex, dbo.lis_buy_bak.pat_phone, dbo.lis_buy_bak.pat_agestr, 
                      dbo.lis_buy_bak.dengdancode, dbo.lis_buy_bak.barcode, dbo.lis_buy_bak.bd, dbo.lis_buy_bak.barhead, dbo.lis_buy_bak.barbody, dbo.lis_buy_bak.req_itemcode, 
                      Rmregion.dbo.sys_user.hospitalname, dbo.lis_dingdanstat.yishengzhenduan
FROM         dbo.lis_buy_bak INNER JOIN
                      Rmregion.dbo.sys_user ON dbo.lis_buy_bak.hospitalcode = Rmregion.dbo.sys_user.hospitalcode INNER JOIN
                      dbo.lis_dingdanstat ON dbo.lis_buy_bak.dengdancode = dbo.lis_dingdanstat.dengdancode AND dbo.lis_buy_bak.hospitalcode = dbo.lis_dingdanstat.hospitalcode
go

